﻿READ-ONLY REPO ALIGNMENT AUDIT SNAPSHOT
========================================
Repository: shoshan19-prog/Matriya-System-Project
Branch: main (as used for export)
Snapshot commit: dd02f19b95d4d975a0fe7ab5212680d9e0418e64
Exported: 2026-04-28 UTC (local machine time)

Included: 7 files from matriya-back/ at the above commit ONLY.
Also: directory listings for matriya-back/sql/ and matriya-back/docs/ (names only).

Excluded by request: .env, vercel-env-*, secrets, API keys, DB URLs (not in this bundle).

Note: Local checkout HEAD at export time may differ; this ZIP is pinned to dd02f19 for alignment with David's request.
Current local HEAD was: (run: git rev-parse HEAD in clone) — not bundled here.
